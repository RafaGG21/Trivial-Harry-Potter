package models.dao;

import entity.nuevasPreguntas;
import entity.quest;
import org.springframework.data.repository.CrudRepository;

public interface InuevasPreguntasDAO extends CrudRepository<nuevasPreguntas,Long> {
}
