package com.example.demo;

import entity.quest;
import entity.usuario;
import models.services.IQuestService;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController

public class trivial {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    private IQuestService questService;

    @GetMapping("/trivial")
    public List<Map<String, Object>> trivial() {

        return jdbcTemplate.queryForList("SELECT * FROM quest");

    }

    @GetMapping("/trivial/{year}")
    public List<Map<String, Object>> trivial2(@PathVariable int year) {

        return jdbcTemplate.queryForList("SELECT * FROM quest where year = "+year);

    }

    @PostMapping("/trivial")
    public ResponseEntity<?> create(@Valid @RequestBody quest pregunta, BindingResult result) {
        quest questNew = null;
        Map<String,Object> response = new HashMap<>();

        if(result.hasErrors()) {
            List<String> errores = result.getFieldErrors()
                    .stream()
                    .map(error->"El campo '" + error.getField() + "' " + error.getDefaultMessage())
                    .collect(Collectors.toList());
            response.put("errores", errores);
            return new ResponseEntity<Map<String,Object>>(response, HttpStatus.BAD_REQUEST);
        }

        try {

            questNew = questService.save(pregunta);
        } catch (DataAccessException e) {
            response.put("mensaje", "Error al acceder a la base de datos");
            response.put("error", e.getMessage().concat(": ").concat(e.getMostSpecificCause().getMessage()));
            return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        // Ha podido insertar el cliente
        response.put("mensaje", "La pregunta ha sido insertada con exito");
        response.put("quest", questNew);
        return new ResponseEntity<Map<String,Object>>(response,HttpStatus.CREATED);
    }





}
