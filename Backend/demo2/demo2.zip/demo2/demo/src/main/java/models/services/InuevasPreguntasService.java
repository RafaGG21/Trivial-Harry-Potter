package models.services;

import entity.nuevasPreguntas;

public interface InuevasPreguntasService {
    nuevasPreguntas save(nuevasPreguntas pregunta);
}
