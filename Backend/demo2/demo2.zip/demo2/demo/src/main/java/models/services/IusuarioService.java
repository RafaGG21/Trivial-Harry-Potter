/*
package models.services;

import com.example.demo.usuario;

import org.springframework.transaction.annotation.Transactional;


public interface IusuarioService {
    public usuario save(usuario user);


    @Transactional(readOnly=true)
    entity.usuario save(entity.usuario user);
}
*/