package models.services;

import entity.nuevasPreguntas;
import models.dao.IQuestDAO;
import models.dao.InuevasPreguntasDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class nuevasPreguntasServiceImpl implements  InuevasPreguntasService{

    @Autowired
    private InuevasPreguntasDAO nuevasDao;


    @Override
    @Transactional
    public nuevasPreguntas save(nuevasPreguntas pregunta) {
        return nuevasDao.save(pregunta);
    }
}
